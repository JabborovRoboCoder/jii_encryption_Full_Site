# jii_encryption_algorithm_Linux
jii shifrlash dasturi Linux OS uchun
